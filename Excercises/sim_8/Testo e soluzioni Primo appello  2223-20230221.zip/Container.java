public interface Container{
   boolean isEmpty();
   void makeEmpty();

}